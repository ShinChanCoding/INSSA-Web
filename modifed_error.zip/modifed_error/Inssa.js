let addCard = document.getElementById("addImage"); // upload image 버튼
let displayCard = document.getElementById("displayImage"); // 
let loadingCard = document.getElementById("loadingImage"); // 
let resultCard = document.getElementById("resultImage");
let fileInput = document.getElementById("fileInput");
let imageBefore = document.getElementById("display-img");
let startBtn = document.getElementById("startBtn");
let imageAfter = document.querySelector(".image-after");
let imageBeforeSM = document.querySelector(".image-before");
let saveBtn = document.getElementById("saveBtn"); //  save 버튼

const myBar = document.querySelector('.my-Bar');
const progress = document.getElementById('progress');
const buttons = document.querySelectorAll('button');
let progressValue = 0;
let intervalId; // 타이머 ID를 저장할 변수를 생성합니다.

const reader = new FileReader();
const formData = new FormData();
let file = null;
const API_URL = 'https://api.remove.bg/v1.0/removebg';
const API_KEY = "rq7LQ1CUGBYF4U5qR6ztTxpq";

const activeScreen = (screen) => {
    addImage.style.display = "none";
    displayImage.style.display = "none";
    loadingImage.style.display = "none";
    resultImage.style.display = "none";
    screen.style.display = "flex";
};

activeScreen(addImage);

fileInput.addEventListener("input", () => {
    file = fileInput.files[0];
    reader.readAsDataURL(file);
    reader.onloadend = () => {
        imageBefore.src = reader.result;
        imageBeforeSM.src = reader.result;
    };
    activeScreen(displayImage);
})

startBtn.addEventListener("click", () => {
    formData.append("image_file", file);
    activeScreen(loadingImage);
    fetch(API_URL, {
        method: "POST",
        headers: {
            "X-API-Key": API_KEY,
        },
        body: formData,
    })
        .then((res) => res.blob())
        .then((blob) => {
            reader.readAsDataURL(blob);
            reader.onloadend = () => {
                imageAfter.src = reader.result;
            };
            activeScreen(resultImage);
        })
});


window.addEventListener('DOMContentLoaded', () => {
    const saveBtn = document.getElementById('saveBtn');

    saveBtn.addEventListener("click", () => {
        readAsDataURL(blob);
    });
});



progress.addEventListener('click', () => {
    buttons.forEach((button) => {
        button.disabled = true;
        button.style.pointerEvents = "none"; // 버튼의 마우스 이벤트 처리를 무력화합니다.
    });
    setTimeout(() => {
        buttons.forEach((button) => {
            button.disabled = false;
            button.style.pointerEvents = "auto"; // 버튼의 마우스 이벤트 처리를 다시 활성화합니다.
        });
    }, 9000);
    myBar.setAttribute('id', 'play');
    runProgressBar();
});

function runProgressBar() {
    intervalId = setInterval(() => {
        if (progressValue < 100) {
            progressValue++;
            myBar.style.width = `${progressValue}%`;
        } else {
            clearInterval(intervalId);
        }
    }, 30);
}



// 버튼 reload에만 연동되는 현상 해결
// 이벤트 버블링 활용 : 하위 요소에서 발생한 이벤트가 상위 요소로 전파

// 가장 상위 요소인 document에 이벤트 리스너를 등록하고, 
// 이벤트 버블링을 이용해서 각각의 버튼에서 발생한 이벤트를 상위 요소에서도 감지
// 각 버튼이 클릭되었을 때, event.target을 사용하여 어떤 버튼이 클릭되었는지 확인
// -> 해당 버튼에 대한 처리를 수행

document.addEventListener('click', function (event) {
    if (event.target.matches('.button')) {
        // button 요소가 클릭되었을 때 실행되는 코드
    } else if (event.target.matches('.button1')) {
        // button1 요소가 클릭되었을 때 실행되는 코드
    } else if (event.target.matches('.button2')) {
        // button2 요소가 클릭되었을 때 실행되는 코드
    } else if (event.target.matches('#startBtn')) {
        // startBtn 요소가 클릭되었을 때 실행되는 코드
    } else if (event.target.matches('.loader')) {
        // loader 요소가 클릭되었을 때 실행되는 코드
    } else if (event.target.matches('.button3')) {
        // button3 요소가 클릭되었을 때 실행되는 코드
    } else if (event.target.matches('.button4')) {
        // button4 요소가 클릭되었을 때 실행되는 코드
    } else if (event.target.matches('.save-btn')) {
        // save-btn 요소가 클릭되었을 때 실행되는 코드
    } else if (event.target.matches('.reload-btn')) {
        // reload-btn 요소가 클릭되었을 때 실행되는 코드
    } else if (event.target.matches('#addImage')) {
        // addImage 요소가 클릭되었을 때 실행되는 코드
    }


});

// 새로운 버튼이 추가되더라도 
// 상위 요소인 document에만 이벤트 리스너를 등록하면 되므로 코드의 수정이 최소화





