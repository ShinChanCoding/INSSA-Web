const myBar = document.querySelector('.my-Bar');
const progress = document.getElementById('progress');
const buttons = document.querySelectorAll('button');

let progressValue = 0;
let intervalId; // 타이머 ID를 저장할 변수를 생성합니다.

progress.addEventListener('click', () => {
    buttons.forEach((button) => {
        button.disabled = true;
        button.style.pointerEvents = "none"; // 버튼의 마우스 이벤트 처리를 무력화합니다.
    });
    setTimeout(() => {
        buttons.forEach((button) => {
            button.disabled = false;
            button.style.pointerEvents = "auto"; // 버튼의 마우스 이벤트 처리를 다시 활성화합니다.
        });
    }, 9000);
    myBar.setAttribute('id', 'play');
    runProgressBar();
});

function runProgressBar() {
    intervalId = setInterval(() => {
        if (progressValue < 100) {
            progressValue++;
            myBar.style.width = `${progressValue}%`;
        } else {
            clearInterval(intervalId);
        }
    }, 30);
}
